<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Formulário Livros</title>
</head>
<body>
    <h3>Formulário de Livros</h3>
    <?php if($errors->any()): ?>
        <ul>
            <?php $__currentLoopData = $errors->any(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
    <?php
        // dd($livros);
        // $route('livros.store');
        if (!empty($livros->id)) {
            $route = route('livros.update', $livros->id);
        }
        else {
            $route = route('livros.store');
        }
    ?>
    <form action="<?php echo e($route); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php if(!empty($livros->id)): ?>
             <?php echo method_field('PUT'); ?>
        <?php endif; ?>
        <input type="hidden" name="id" value="
            <?php if(!empty($livros->id)): ?>
                    <?php echo e($livros->id); ?>

                <?php elseif(!empty(old('id'))): ?>
                    <?php echo e(old('id')); ?>

                <?php else: ?>
                    <?php echo e(''); ?>

            <?php endif; ?>">

        <label for="">Nome</label><br>
        <input type="text" name="nome" value="<?php if(!empty($livros->nome)): ?><?php echo e($livros->nome); ?><?php elseif(!empty(old('nome'))): ?><?php echo e(old('nome')); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>"><br><br>
        <label for="">Editora</label><br>
        <input type="text" name="editora" value="<?php if(!empty($livros->editora)): ?><?php echo e($livros->editora); ?><?php elseif(!empty(old('editora'))): ?><?php echo e(old('editora')); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>"><br><br>
        <label for="">Ano de Publicação</label><br>
        <input type="number" name="ano_publi" value="<?php if(!empty($livros->ano_publi)): ?><?php echo e($livros->ano_publi); ?><?php elseif(!empty(old('ano_publi'))): ?><?php echo e(old('ano_publi')); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>"><br><br>
        <label for="">Autor</label><br>
        <input type="text" name="autor" value="<?php if(!empty($livros->autor)): ?><?php echo e($livros->autor); ?><?php elseif(!empty(old('autor'))): ?><?php echo e(old('autor')); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>"><br><br>
        <label for="">Preço</label><br>
        <input type="number" name="preco" step='0.01' value="<?php if(!empty($livros->preco)): ?><?php echo e($livros->preco); ?><?php elseif(!empty(old('preco'))): ?><?php echo e(old('preco')); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>"><br><br>
        <button type="submit">Salvar</button><br>
        <a href="<?php echo e(route('livros.index')); ?>">Voltar</a>
    </form>
</body>
</html>
<?php /**PATH C:\laragon\www\16-08\resources\views/livros/form.blade.php ENDPATH**/ ?>