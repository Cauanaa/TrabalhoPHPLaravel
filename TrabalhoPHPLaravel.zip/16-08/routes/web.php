<?php

use Illuminate\Support\Facades\Route;
//importar o arquivo do controlador
use App\Http\Controllers\UsuarioController;
use App\Http\Controllers\LivrosController;
use App\Http\Controllers\FuncionariosController;
use App\Http\Controllers\VendasController;

//chamar uma função do controlador
Route::get('/usuario', [UsuarioController::class, 'index']);

//rota livros
Route::get('/livros',
 [LivrosController::class, 'index'])->name('livros.index');

Route::get('/livros/create',
 [LivrosController::class, 'create'])->name('livros.create');

 Route::post('/livros',
[LivrosController::class, 'store'])->name('livros.store');

Route::get('/livros/edit/{id}',
 [LivrosController::class, 'edit'])->name('livros.edit');

 Route::put('/livros/update/{id}',
[LivrosController::class, 'update'])->name('livros.update');

Route::get('/livros/destroy/{id}',
 [LivrosController::class, 'destroy'])->name('livros.destroy');

 Route::post('/livros/search',
[LivrosController::class, 'search'])->name('livros.search');

//chamar uma página em HTML
Route::get('/pagina', function () {
    return view('index');
});

//chama um HTML
Route::get('/teste', function () {
    return "<h4>Olá Mundo Laravel!</h4>";
});


Route::get('/', function () {
    return view('welcome');
});


//rota funcionarios
Route::get('/funcionarios',
 [FuncionariosController::class, 'index'])->name('funcionarios.index');

Route::get('/funcionarios/create',
 [FuncionariosController::class, 'create'])->name('funcionarios.create');

 Route::post('/funcionarios',
[FuncionariosController::class, 'store'])->name('funcionarios.store');

Route::get('/funcionarios/edit/{id}',
 [FuncionariosController::class, 'edit'])->name('funcionarios.edit');

 Route::put('/funcionarios/update/{id}',
[FuncionariosController::class, 'update'])->name('funcionarios.update');

Route::get('/funcionarios/destroy/{id}',
 [FuncionariosController::class, 'destroy'])->name('funcionarios.destroy');

 Route::post('/funcionarios/search',
[FuncionariosController::class, 'search'])->name('funcionarios.search');

//rota vendas
Route::get('/vendas',
 [VendasController::class, 'index'])->name('vendas.index');

Route::get('/vendas/create',
 [VendasController::class, 'create'])->name('vendas.create');

 Route::post('/vendas',
[VendasController::class, 'store'])->name('vendas.store');

Route::get('/vendas/edit/{id}',
 [VendasController::class, 'edit'])->name('vendas.edit');

 Route::put('/vendas/update/{id}',
[VendasController::class, 'update'])->name('vendas.update');

Route::get('/vendas/destroy/{id}',
 [VendasController::class, 'destroy'])->name('vendas.destroy');

 Route::post('/vendas/search',
[VendasController::class, 'search'])->name('vendas.search');
