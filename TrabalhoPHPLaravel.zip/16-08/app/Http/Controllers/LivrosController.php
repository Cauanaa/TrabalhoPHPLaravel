<?php

namespace App\Http\Controllers;

use App\Models\Livros;
use App\Models\CategoriaLivros;
use Illuminate\Http\Request;

class LivrosController extends Controller
{
    /**
     * Carrega a listagem de dados
     */
    public function index()
    {
        $livros = Livros::all();

        return view('livros.list')->with(['livros'=> $livros]);
    }

    /**
     * Carrega o formulário
     */
    public function create()
    {

        return view('livros.form');
    }

    /**
     * Salva os dados do formulário
     */
    public function store(Request $request)
    {

        $request->validate([
            'nome'=>'max:100',
            'editora'=>'max:100',
            'ano_publi'=>'max:4',
            'autor'=>'max:100',
            'preco'=>'max:5'
        ],[
            'nome.max'=>" Só é permitido 100 caracteres no :attribute !",
            'editora.max'=>" Só é permitido 100 caracteres no :attribute !",
            'ano_publi.max'=>" Só é permitido 4 caracteres no :attribute !",
            'autor.max'=>" Só é permitido 100 caracteres no :attribute !",
            'preco.max'=>" Só é permitido 5 caracteres no :attribute !",
        ]);

        $dados = ['nome'=> $request->nome,
            'editora'=> $request->editora,
            'ano_publi'=> $request->ano_publi,
            'autor'=> $request->autor,
            'preco'=>$request->preco,
        ];


        Livros::create($dados); //ou  $request->all()

        return redirect('livros')->with('success', "Cadastrado com sucesso!");
    }

    /**
     * Carrega apenas 1 registro da tabela
     */
    public function show(Livros $aluno)
    {
        //
    }

    /**
     * Carrega o formulário para edição
     */
    public function edit($id)
    {
        $livros = Livros::find($id);


        return view('livros.form')->with(['livros'=>$livros]);
    }

    /**
     * Atualiza os dados do formulário
     */
    public function update(Request $request, Livros $livro)
    {
       
        $request->validate([
            'nome'=>'max:100',
            'editora'=>'max:100',
            'ano_publi'=>'max:4',
            'autor'=>'max:100',
            'preco'=>'max:5'
        ],[
            'nome.max'=>" Só é permitido 100 caracteres no :attribute !",
            'editora.max'=>" Só é permitido 100 caracteres no :attribute !",
            'ano_publi.max'=>" Só é permitido 4 caracteres no :attribute !",
            'autor.max'=>" Só é permitido 100 caracteres no :attribute !",
            'preco.max'=>" Só é permitido 5 caracteres no :attribute !",
        ]);

        $dados = ['nome'=> $request->nome,
            'editora'=> $request->editora,
            'ano_publi'=> $request->ano_publi,
            'autor'=> $request->autor,
            'preco'=>$request->preco,
        ];

        Livros::updateOrCreate(['id'=>$request->id],$dados);

        return redirect('livros')->with('success', "Atualizado com sucesso!");
    }

    /**
     * Remove o registro do banco de dados
     */
    public function destroy($id)
    {
        $livro = Livros::find($id);

        $livro->delete();

        return redirect('livros')->with('success', "Removido com sucesso!");
    }
    public function search(Request $request)
    {
        if(!empty($request->valor)){
            $livros = Livros::where($request->tipo, 'like', "%". $request->valor."%")->get();
        } else{
            $livros = Livros::all();
        }
        return view('livros.list')->with(['livros'=> $livros]);
    }

}
