<?php

namespace App\Http\Controllers;

use App\Models\Funcionarios;
use Illuminate\Http\Request;

class FuncionariosController extends Controller
{
    /**
     * Carrega a listagem de dados
     */
    public function index()
    {
        $funcionarios = Funcionarios::all();

        return view('funcionarios.list')->with(['funcionarios'=> $funcionarios]);
    }

    /**
     * Carrega o formulário
     */
    public function create()
    {

        return view('funcionarios.form');
    }

    /**
     * Salva os dados do formulário
     */
    public function store(Request $request)
    {

        $request->validate([
            'nome'=>'max:100',
            'cpf'=>'max:14',
            'email'=>'max:100'
        ],[
            'nome.max'=>" Só é permitido 100 caracteres no :attribute !",
            'cpf.max'=>" Só é permitido 14 caracteres no :attribute !",
            'email.max'=>" Só é permitido 100 caracteres no :attribute !",
        ]);

        $dados = ['nome'=> $request->nome,
            'data_admissao'=> $request->data_admissao,
            'cpf'=> $request->cpf,
            'email'=> $request->email,
        ];


        Funcionarios::create($dados); //ou  $request->all()

        return redirect('funcionarios')->with('success', "Cadastrado com sucesso!");
    }

    /**
     * Carrega apenas 1 registro da tabela
     */
    public function show(Funcionarios $aluno)
    {
        //
    }

    /**
     * Carrega o formulário para edição
     */
    public function edit($id)
    {
        $funcionarios = Funcionarios::find($id);


        return view('funcionarios.form')->with(['funcionarios'=>$funcionarios]);
    }

    /**
     * Atualiza os dados do formulário
     */
    public function update(Request $request, Funcionarios $funcionario)
    {
       
        $request->validate([
            'nome'=>'max:100',
            'cpf'=>'max:14',
            'email'=>'max:100'
        ],[
            'nome.max'=>" Só é permitido 100 caracteres no :attribute !",
            'cpf.max'=>" Só é permitido 14 caracteres no :attribute !",
            'email.max'=>" Só é permitido 100 caracteres no :attribute !",
        ]);

        $dados = ['nome'=> $request->nome,
            'data_admissao'=> $request->data_admissao,
            'cpf'=> $request->cpf,
            'email'=> $request->email,
        ];

        Funcionarios::updateOrCreate(['id'=>$request->id],$dados);

        return redirect('funcionarios')->with('success', "Atualizado com sucesso!");
    }

    /**
     * Remove o registro do banco de dados
     */
    public function destroy($id)
    {
        $funcionario = Funcionarios::find($id);

        $funcionario->delete();

        return redirect('funcionarios')->with('success', "Removido com sucesso!");
    }
    public function search(Request $request)
    {
        if(!empty($request->valor)){
            $funcionarios = Funcionarios::where($request->tipo, 'like', "%". $request->valor."%")->get();
        } else{
            $funcionarios = Funcionarios::all();
        }
        return view('funcionarios.list')->with(['funcionarios'=> $funcionarios]);
    }

}
