<?php

namespace App\Http\Controllers;

use App\Models\Funcionarios;
use App\Models\Livros;
use App\Models\Vendas;
use Illuminate\Http\Request;

class VendasController extends Controller
{
    /**
     * Carrega a listagem de dados
     */
    public function index()
    {
        $vendas = Vendas::all();

        return view('vendas.list')->with(['vendas'=> $vendas]);
    }

    /**
     * Carrega o formulário
     */
    public function create()
    {
        $funcionarios = Funcionarios::orderBy('nome')->get();
        $livros = Livros::orderBy('nome')->get();

        return view('vendas.form')->with(['funcionarios'=>$funcionarios,'livros'=>$livros ]);
    }

    /**
     * Salva os dados do formulário
     */
    public function store(Request $request)
    {

        $request->validate([
            'nome'=>'max:100',
        ],[
            'nome.max'=>" Só é permitido 100 caracteres no :attribute !",
        ]);

        $dados = ['nome'=> $request->nome,
            'livros_id'=> $request->livros_id,
            'funcionarios_id'=> $request->funcionarios_id,
            'data'=> $request->data,
        ];


        Vendas::create($dados); //ou  $request->all()

        return redirect('vendas')->with('success', "Cadastrado com sucesso!");
    }

    /**
     * Carrega apenas 1 registro da tabela
     */
    public function show(Vendas $aluno)
    {
        //
    }

    /**
     * Carrega o formulário para edição
     */
    public function edit($id)
    {
        $vendas = Vendas::find($id);

        $funcionarios = Funcionarios::orderBy('nome')->get();
        $livros = Livros::orderBy('nome')->get();

        return view('vendas.form')->with(['vendas'=>$vendas, 'funcionarios'=>$funcionarios, 'livros'=>$livros]);
    }

    /**
     * Atualiza os dados do formulário
     */
    public function update(Request $request, Vendas $venda)
    {
       
        $request->validate([
            'nome'=>'max:100',
        ],[
            'nome.max'=>" Só é permitido 100 caracteres no :attribute !",
        ]);

        $dados = ['nome'=> $request->nome,
            'livros_id'=> $request->livros_id,
            'funcionarios_id'=> $request->funcionarios_id,
            'data'=> $request->data,
        ];

        Vendas::updateOrCreate(['id'=>$request->id],$dados);

        return redirect('vendas')->with('success', "Atualizado com sucesso!");
    }

    /**
     * Remove o registro do banco de dados
     */
    public function destroy($id)
    {
        $venda = Vendas::find($id);

        $venda->delete();

        return redirect('vendas')->with('success', "Removido com sucesso!");
    }
    public function search(Request $request)
    {
        if(!empty($request->valor)){
            $vendas = Vendas::where($request->tipo, 'like', "%". $request->valor."%")->get();
        } else{
            $vendas = Vendas::all();
        }
        return view('vendas.list')->with(['vendas'=> $vendas]);
    }

}
