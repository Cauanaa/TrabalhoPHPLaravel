<?php

namespace Database\Seeders;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class LivrosSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
{
    $faker = \Faker\Factory::create('pt_BR');
    for ($i=0; $i<10; $i++) {
        DB::table('livros')->insert([
            'nome' => $faker->name,
            'editora' => $faker->name,
            'ano_publi' => $faker->numberBetween(2000,2023),
            'autor' => $faker->name,
            'preco' => $faker->randomFloat(2, 12, 150000),
        ]);
    }
}
}
