<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('vendas', function (Blueprint $table) {
            $table->id();
            $table->string('nome',100);
            $table->date('data');
            $table->timestamps();
        });

        Schema::disableForeignKeyConstraints();

        Schema::table('vendas', function (Blueprint $table) {
            $table->foreignId('livros_id')->nullable()->constrained('livros')->default(null);
            $table->foreignId('funcionarios_id')->nullable()->constrained('funcionarios')->default(null);
        });

        Schema::enableForeignKeyConstraints();
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('vendas');
    }
};
