<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Formulário Vendas</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style>
        input, select {
            margin-bottom: 18px;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav">
      <a class="nav-item nav-link" href="{{route('livros.index')}}">Livros</a>
      <a class="nav-item nav-link" href="{{route('funcionarios.index')}}">Funcionários</a>
      <a class="nav-item nav-link active" href="{{route('vendas.index')}}">Vendas <span class="sr-only">(current)</span></a>
    </div>
  </div>
</nav>
<div  class="container" style="padding: 20px 0">
    <h2>Formulário de Vendas</h2>
    @if ($errors->any())
        <ul>
            @foreach ($errors->any() as $error)
            <li>{{$error}}</li>
            @endforeach
        </ul>
    @endif
    @php
        // dd($vendas);
        // $route('vendas.store');
        if (!empty($vendas->id)) {
            $route = route('vendas.update', $vendas->id);
        }
        else {
            $route = route('vendas.store');
        }
    @endphp
    <form action="{{$route}}" method="POST" enctype="multipart/form-data">
        @csrf
        @if (!empty($vendas->id))
             @method('PUT')
        @endif
        <input type="hidden" name="id" value="
            @if (!empty($vendas->id))
                    {{$vendas->id}}
                @elseif (!empty(old('id')))
                    {{old('id')}}
                @else
                    {{''}}
            @endif">

        <label for="">Nome</label>
        <input class="form-control" type="text" name="nome" value="@if(!empty($vendas->nome)){{$vendas->nome}}@elseif(!empty(old('nome'))){{old('nome')}}@else{{''}}@endif">
        <label for="">Data</label>
        <input class="form-control" type="date" required name="data" value="@if(!empty($vendas->data)){{str_replace(' 00:00:00','', $vendas->data)}}@elseif(!empty(old('data'))){{old('data')}}@else{{''}}@endif">
        
        <label for="">Funcionário</label>
        <select class="form-control" name="funcionarios_id">
            @foreach ($funcionarios as $item )
                @if (!empty($vendas->funcionarios_id) and $vendas->funcionarios_id == $item->id)
                    <option value="{{$item->id}}" selected>{{$item->nome}}</option>
                @else
                    <option value="{{$item->id}}">{{$item->nome}}</option>
                @endif
            @endforeach
        </select>

        <label for="">Livro</label>
        <select class="form-control" name="livros_id">
            @foreach ($livros as $item )
                @if (!empty($vendas->livros_id) and $vendas->livros_id == $item->id)
                    <option value="{{$item->id}}" selected>{{$item->nome}}</option>
                @else
                    <option value="{{$item->id}}">{{$item->nome}}</option>
                @endif
            @endforeach
            
        </select>
        
        <button type="submit" class="btn btn-success" style="height: 38px">Salvar</button>
        <a href="{{route('vendas.index')}}" class="btn btn-primary" style="height: 38px">Voltar</a>
    </form>
    </div>
</body>
</html>
