<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Formulário Livros</title>
</head>
<body>
    <h3>Formulário de Livros</h3>
    @if ($errors->any())
        <ul>
            @foreach ($errors->any() as $error)
            <li>{{$error}}</li>
            @endforeach
        </ul>
    @endif
    @php
        // dd($livros);
        // $route('livros.store');
        if (!empty($livros->id)) {
            $route = route('livros.update', $livros->id);
        }
        else {
            $route = route('livros.store');
        }
    @endphp
    <form action="{{$route}}" method="POST" enctype="multipart/form-data">
        @csrf
        @if (!empty($livros->id))
             @method('PUT')
        @endif
        <input type="hidden" name="id" value="
            @if (!empty($livros->id))
                    {{$livros->id}}
                @elseif (!empty(old('id')))
                    {{old('id')}}
                @else
                    {{''}}
            @endif">

        <label for="">Nome</label><br>
        <input type="text" name="nome" value="@if(!empty($livros->nome)){{$livros->nome}}@elseif(!empty(old('nome'))){{old('nome')}}@else{{''}}@endif"><br><br>
        <label for="">Editora</label><br>
        <input type="text" name="editora" value="@if(!empty($livros->editora)){{$livros->editora}}@elseif(!empty(old('editora'))){{old('editora')}}@else{{''}}@endif"><br><br>
        <label for="">Ano de Publicação</label><br>
        <input type="number" name="ano_publi" value="@if(!empty($livros->ano_publi)){{$livros->ano_publi}}@elseif(!empty(old('ano_publi'))){{old('ano_publi')}}@else{{''}}@endif"><br><br>
        <label for="">Autor</label><br>
        <input type="text" name="autor" value="@if(!empty($livros->autor)){{$livros->autor}}@elseif(!empty(old('autor'))){{old('autor')}}@else{{''}}@endif"><br><br>
        <label for="">Preço</label><br>
        <input type="number" name="preco" step='0.01' value="@if(!empty($livros->preco)){{$livros->preco}}@elseif(!empty(old('preco'))){{old('preco')}}@else{{''}}@endif"><br><br>
        <button type="submit">Salvar</button><br>
        <a href="{{route('livros.index')}}">Voltar</a>
    </form>
</body>
</html>
