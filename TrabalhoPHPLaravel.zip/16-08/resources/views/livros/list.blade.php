<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Listagem Livros</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
 <style>
        th, td {
            padding: 4px 12px;
        }
    </style>
</head>
<body>
    <h3>Listagem de Livros</h3>
    <form action="{{route('livros.search')}}" method="post">
        @csrf
        <select name="tipo">
            <option value="nome">Nome</option>
            <option value="editora">Editora</option>
            <option value="ano_publi">Ano de Publicação</option>
            <option value="autor">Autor</option>
            <option value="preco">Preço</option>
        </select>
        <input type="text" name="valor" placeholder="Pesquisar">
        <button type="submit" class="btn btn-primary">Buscar</button>
        <a href="{{route('livros.create')}}">Cadastrar</a><br><br>
    </form>
    <table border="1" style="border-collapse: collapse">
        <tr>
          <th>ID</th>
          <th>Nome</th>
          <th>Editora</th>
          <th>Ano de Publicação</th>
          <th>Autor</th>
          <th>Preço</th>
        </tr>
        @foreach ($livros as $item)
            <tr>
                <td>{{$item->id}}</td>
                <td>{{$item->nome}}</td>
                <td>{{$item->editora}}</td>
                <td>{{$item->ano_publi}}</td>
                <td>{{$item->autor}}</td>
                <td>R$ {{$item->preco}}</td>
                
                <td><a href="{{route('livros.edit', $item->id)}}">Editar</a></td>
                <td><a href="{{route('livros.destroy', $item->id)}}" onclick="return confirm('Deseja Excluir?')">Excluir</a></td>
            </tr>
        @endforeach
      </table>
</body>
</html>
