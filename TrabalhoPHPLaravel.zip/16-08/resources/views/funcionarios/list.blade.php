<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Listagem Funcionários</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
 <style>
        th, td {
            padding: 4px 12px;
        }
    </style>
</head>
<body>
    <h3>Listagem de Funcionários</h3>
    <form action="{{route('funcionarios.search')}}" method="post">
        @csrf
        <select name="tipo">
            <option value="nome">Nome</option>
            <option value="data_admissao">Data de Admissão</option>
            <option value="cpf">CPF</option>
            <option value="email">Email</option>
        </select>
        <input type="text" name="valor" placeholder="Pesquisar">
        <button type="submit" class="btn btn-primary">Buscar</button>
        <a href="{{route('funcionarios.create')}}">Cadastrar</a><br><br>
    </form>
    <table border="1" style="border-collapse: collapse">
        <tr>
          <th>ID</th>
          <th>Nome</th>
          <th>Data de Admissão</th>
          <th>CPF</th>
          <th>Email</th>
        </tr>
        @foreach ($funcionarios as $item)
            <tr>
                <td>{{$item->id}}</td>
                <td>{{$item->nome}}</td>
                <td>{{str_replace(' 00:00:00','', $item->data_admissao)}}</td>
                <td>{{$item->cpf}}</td>
                <td>{{$item->email}}</td>4
                
                <td><a href="{{route('funcionarios.edit', $item->id)}}">Editar</a></td>
                <td><a href="{{route('funcionarios.destroy', $item->id)}}" onclick="return confirm('Deseja Excluir?')">Excluir</a></td>
            </tr>
        @endforeach
      </table>
</body>
</html>
