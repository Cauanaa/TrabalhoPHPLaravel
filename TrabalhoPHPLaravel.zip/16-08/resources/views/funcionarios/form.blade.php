@extends('base.app')

@section('titulo', 'Formulário de Aluno')

@section('content')

    @if ($errors->any())
        <ul>
            @foreach ($errors->any() as $error)
            <li>{{$error}}</li>
            @endforeach
        </ul>
    @endif
    @php
        if (!empty($funcionarios->id)) {
            $route = route('funcionarios.update', $funcionarios->id);
        }
        else {
            $route = route('funcionarios.store');
        }
    @endphp
    <div class="mx-auto py-12 divide-y md:max-w-4x1">
        <div class="py-12">
        <h3 class="pt-4 text-2xl font-medium">Formulário de Funcionários</h3>
    <form action="{{$route}}" method="POST" enctype="multipart/form-data" class="bg-white shadow-md rounded px-8 pt-6 pb-6mb-4">
        @csrf
        @if (!empty($funcionarios->id))
             @method('PUT')
        @endif
        <input type="hidden" name="id" value="
            @if (!empty($funcionarios->id))
                    {{$funcionarios->id}}
                @elseif (!empty(old('id')))
                    {{old('id')}}
                @else
                    {{''}}
            @endif">
        <label class="block">
            <span class="text-gray-700">Nome</span><br>
            <input type="text" name="nome" class="mt-0 block w-full px-0.5 border-0 border-b-2 border-gray-200 focus:ring-0 focus:border-black" value="@if(!empty($funcionarios->nome)){{$funcionarios->nome}}@elseif(!empty(old('nome'))){{old('nome')}}@else{{''}}@endif"><br><br>
        </label>
        <div class="md-4 md:mr-2 md:mb-0">
        <label class="block">
            <span class="text-gray-700">Data de Admissão</span><br>
            <input type="text" name="data_admissao" class="mt-0 block w-full px-0.5 border-0 border-b-2 border-gray-200 focus:ring-0 focus:border-black" value="@if(!empty($funcionarios->data_admissao)){{str_replace(' 00:00:00','', $funcionarios->data_admissao)}}@elseif(!empty(old('data_admissao'))){{old('data_admissao')}}@else{{''}}@endif"><br><br>
        </label>
        <label class="block">
            <span class="text-gray-700">CPF</span><br>
            <input type="text" name="cpf" class="mt-0 block w-full px-0.5 border-0 border-b-2 border-gray-200 focus:ring-0 focus:border-black" value="@if(!empty($funcionarios->cpf)){{$funcionarios->cpf}}@elseif(!empty(old('cpf'))){{old('cpf')}}@else{{''}}@endif"><br><br>
        </label>
        </div>
        <label class="block">
            <span class="text-gray-700">Email</span><br>
            <input type="text" name="email" class="mt-0 block w-full px-0.5 border-0 border-b-2 border-gray-200 focus:ring-0 focus:border-black" value="@if(!empty($funcionarios->email)){{$funcionarios->email}}@elseif(!empty(old('email'))){{old('email')}}@else{{''}}@endif"><br><br>
        </label>
        
        <button class="rounded-full bg-green-700 w-40 px-5 py-2 font-bold hover:bg-green-300" type="submit">Salvar</button>
        <a class="rounded-full bg-blue-700 w-40 px-5 py-2 font-bold hover:bg-blue-300" href="{{route('funcionarios.index')}}">Voltar</a>
    </form>
    </div>
    </div>
@endsection
    